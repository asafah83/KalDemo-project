package tests;

import io.qameta.allure.Description;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.LoginPage;
import io.qameta.allure.Description;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class E2Etests extends BaseTest {

    //        @BeforeMethod
//        public void setUpProductsPages() {
//            // Initialize commonly used pages
//            lp = new LoginPage(driver);
//            productsPage = new ProductsPage(driver);
//        }
    //////////////////////////******* Tests list *********/////////////////////////////////////////////////////////

    @Test
    @Description("Test 1 - Login with a valid user, to the website and Create a new Ad")
    private void e2eTest_loginAndCreateAd() throws InterruptedException {
        //   lp.login("standard_user", "secret_sauce");
      //  productsPage.verifyPageTitle("Products"); // Verify login success
    }
}
