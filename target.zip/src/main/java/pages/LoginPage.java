package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class LoginPage extends BasePage {
    @FindBy(css = "[type='submit']")
    WebElement connectPrimaryButton;
    @FindBy(css = "#user-d21758b")
    WebElement userNameField;
    @FindBy(css = "#password-d21758b")
    WebElement passwordField;
    @FindBy(css = "elementor-button-text")
    WebElement connectionButton;
    @FindBy(css = "")
    WebElement errorMessage;

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public void login(String userNameValue, String passwordValue) throws InterruptedException {
        click(connectPrimaryButton);
        fillText(userNameField, userNameValue);
        fillText(passwordField, passwordValue);
        click(connectionButton);
        sleep(3000);
    }
    public void loginUsingValidUserDetails() throws InterruptedException {
        login("tester", "tester123!@#qwe");
    }

    public String getErrorMessage() {
        return getText(errorMessage);
    }
    public void verifyTheErrorMessage(String expectedMessage) {
        String actualMessage = getText(errorMessage);
        Assert.assertEquals(actualMessage, expectedMessage);
    }
}




